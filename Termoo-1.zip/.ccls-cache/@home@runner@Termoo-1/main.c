#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define alfabeto 26

char letras[alfabeto] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
                         'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                         's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

void comparacao(
    char A[],
    char B[]) { //Essa parte do código pega a intersecção dos arrays 
  for (int i = 0; i < 5;
       i++) { // Mas mudando para as regras do jogo
    if (A[i] == B[i]) {
      printf("^");
    } else if (strchr(A, B[i]) !=
               NULL) { // Esse verifica se a letra da tentativa está na palavra
                       // mas no lugar errado
      printf("!");
    } else {
      printf("x");
    }
  }
  printf("\n");
}

char gerarletra() {
  int indice = rand() % alfabeto; // gera letras aleatórias que estão no
                                  // alfabeto
  return letras[indice];
}

void gerar(char palavra[]) {
  for (int i = 0; i < 5; i++) {
    palavra[i] =
        gerarletra(); // um loop for que pega 5 letras aleatórias geradas
  }
  palavra[5] = '\0'; // declarei o fim da string pra evitar erros
}

int main() {
  printf("Wordle / Termoo \n");
  printf("Já sabe como jogar?, digite 1 para sim e 2 para não \n");
  int regra;
  scanf("%d", &regra);
  if(regra == 2){
    printf("Uma palavra de 5 letras será sorteada e você tentará acertá-la, para isso você deve tentar outras palavras com até 5 letras. \nSe a palavra sorteada possuir uma letra da palavra que você tentou adivinhar e ela estiver no lugar correto, o símbolo '^' aparecerá. \nSe a palavra possuir a letra mas estiver no lugar errado, o símbolo '!' aparecerá. \nCaso a palavra não possua a letra, o símbolo 'X' aparecerá.\n");
  }
  printf("Gerando palavra, um momento por favor \n");
  srand(time(NULL));
  bool acertou = false;    //por enquanto a variável está falsa já que o jogador ainda não                                     acertou a palavra
  clock_t start, end;    //variáveis função time
  double cpu_time_used; 
  char palavra[6];  //array que vai guardar a palavra gerada
  gerar(palavra);
  char tentativa[6]; // alterado para permitir uma palavra com tamanho máximo de
                     // 5 letras
  int ntentativa = 0;
  char nome[20];
  FILE *dicionario = fopen("dicionario.txt",
                           "r"); // abre o arquivo do dicionário em modo leitura
  char busca[200];
  if (dicionario == NULL) {
    printf("Erro ao abrir o arquivo dicionario.txt\n");
    return 0;
  }
  bool palavra_encontrada = false; // enquanto a palavra encontrada está em
                                   // false
  while (!palavra_encontrada) { // ele gera uma palavra nova até que ela seja
                                // encontrada
    gerar(palavra);             // no dicionário
    fseek(dicionario, 0, SEEK_SET);
    while (fgets(busca, sizeof(busca), dicionario)) {
      if (strlen(busca) == 6 && strstr(busca, palavra) != NULL) { //busca a palavra no dicionário.txt
        palavra_encontrada = true;
        break;
      }
    }
  }
  fclose(dicionario);

  printf("Palavra gerada, boa sorte! \n");
  start = clock();
  for (int w = 0; w < 7; w++) {
    printf("\n");
    ++ntentativa;  //contador do n° de tentativas
    scanf("%s", tentativa);
    comparacao(palavra, tentativa);
    if (strcmp(palavra, tentativa) == 0) { // verifica se acertou a palavra
      acertou = true;
      break;
    }
  }
  if (acertou) {
    end = clock();
    cpu_time_used = ((double)(end - start) / CLOCKS_PER_SEC);
    printf("Parabéns, você acertou a palavra! \n");
    printf("Digite seu nome: ");
    scanf("%s", nome);
    FILE *score = fopen("scores.txt", "a");
    if (score == NULL) {
      printf("Erro ao abrir o arquivo");
    }
    fprintf(score, "Nome: %s \n", nome);
    fprintf(score, "A palavra era %s e foram usadas %d tentativas, o tempo utilizado foi de %f \n\n ", palavra, ntentativa, cpu_time_used);
    
    fclose(score);
  }

  else {
    printf("Fim das tentativas, a palavra era %s\n", palavra);
  }
}
